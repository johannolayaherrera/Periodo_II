package com.episodios.control.controller.model;

import lombok.Data;
import lombok.ToString;

import java.util.List;

/**
 * Created by cindymargaritapachecoalvarez on 18/06/17.
 */
@Data
@ToString
public class ApiPainEpisodeDetail extends AbstractApiObject {

  private String medicines;
  private String painLocalization;
  private String painLocalizationLevel;
  private String additionalInfo;
  private Long painLevelId;
  private List<Long> habitsId;

}
