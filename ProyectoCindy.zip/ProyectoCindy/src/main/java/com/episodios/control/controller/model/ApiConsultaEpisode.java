package com.episodios.control.controller.model;

import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

/**

 */
@Data
@ToString
public class ApiConsultaEpisode extends AbstractApiObject{
    private String tipoIdentificacion;
    private Long identificacion;
    private String nombreApellido;
    private String fecha;
    private String medicamento;
    private String localizacionDolor;
    private String intensidadDolor;
    private String habitos;
    private String informacionAdicional;
}
