package com.episodios.control.data.repository;

import com.episodios.control.data.entities.AutomaticAnalysis;
import com.episodios.control.data.entities.Habit;
import com.episodios.control.data.entities.PainEpisodeDetail;
import com.episodios.control.data.entities.PainLevel;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by cindymargaritapachecoalvarez on 19/06/17.
 */
public interface AutomaticAnalysisRepository extends CrudRepository<AutomaticAnalysis, Integer> {

  @Cacheable("findDescriptionByPainLevelAndHabitIn")
  @Query("select description from AutomaticAnalysis where painLevel.id =?1 and habit.id in (?2)")
  List<String> findDescriptionByPainLevelAndHabitIn(Long painLevelId, List<Long> habitIds);
}
