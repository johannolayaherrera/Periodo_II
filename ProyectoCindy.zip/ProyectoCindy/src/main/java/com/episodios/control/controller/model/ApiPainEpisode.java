package com.episodios.control.controller.model;


import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.List;

/**
 * Created by cindymargaritapachecoalvarez on 17/06/17.
 */
@Data
@ToString
@EqualsAndHashCode
public class ApiPainEpisode extends AbstractApiObject {

  private Long patientId;
  private ApiPainEpisodeDetail details;
}
