package com.episodios.control.data.entities;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by cindymargaritapachecoalvarez on 16/06/17.
 */
@Data
@Entity
@Table(name = "habito")
@SequenceGenerator(name = "habito_id_habito_seq"
        , sequenceName = "habito_id_habito_seq", allocationSize = 1)
public class Habit implements Serializable{

  /** The default serial version id */
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "id_habito")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "habito_id_habito_seq")
  private Long id;
  @ManyToOne
  @JoinColumn(name = "id_categoria_habito", nullable = false)
  private HabitCategory habitCategory;
  @Column(name = "descripcion")
  private String description;

  public Habit(){

  }

  public Habit(Long id){
    this.id = id;
  }
}
