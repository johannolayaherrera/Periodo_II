package com.episodios.control.service.impl;


import com.episodios.control.data.entities.PainEpisode;
import com.episodios.control.data.entities.PainEpisodeDetail;
import com.episodios.control.data.repository.PainEpisodeDetailRepository ;
import com.episodios.control.service.IPainEpisodeDeatilService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by usuario on 19/06/2017.
 */
@Service
public class PainEpisodeDeatilService implements IPainEpisodeDeatilService {

    @Autowired
    private PainEpisodeDetailRepository painEpisodeDetailRepository;

    public List<PainEpisodeDetail> getPainEpisodeDetailOfEpisodes(List<PainEpisode> listPainEpisode)
    {
        List<PainEpisodeDetail> listPainEpisodeDetail = new ArrayList<PainEpisodeDetail>();

        for (PainEpisode painEpisode: listPainEpisode)
        {
            Iterable<PainEpisodeDetail> episodeDetail = painEpisodeDetailRepository.findPainEpisodeDetailByIDPainEpisode(painEpisode.getId());
            listPainEpisodeDetail.addAll((List)episodeDetail);
        }
        return listPainEpisodeDetail;

    }


}

