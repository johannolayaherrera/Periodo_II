package com.episodios.control.data.entities;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.io.Serializable;

/**
 * Created by cindymargaritapachecoalvarez on 19/06/17.
 */
@Data
@Embeddable
public class PainEpisodeDetailHabitKeys implements Serializable {

  @Column(name = "id_detalle_episodio")
  private Long painEpisodeDetailId;
  @Column(name = "id_habito")
  private Long habitId;

  public PainEpisodeDetailHabitKeys(){

  }

  public PainEpisodeDetailHabitKeys(Long painEpisodeDetailId, Long habitId) {
    this.painEpisodeDetailId = painEpisodeDetailId;
    this.habitId = habitId;
  }
}
