package com.episodios.control.data.entities;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by cindymargaritapachecoalvarez on 16/06/17.
 */
@Data
@Entity
@Table(name = "doctor")
@SequenceGenerator(name = "doctor_id_doctor_seq"
        , sequenceName = "doctor_id_doctor_seq", allocationSize = 1)
public class Doctor implements Serializable {

  /**
   * The default serial version id
   */
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "id_doctor")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "doctor_id_doctor_seq")
  private Integer id;
  @ManyToOne
  @JoinColumn(name = "id_usuario", nullable = false)
  private User user;
  @Column(name = "especialidad")
  private String specialty;
}
