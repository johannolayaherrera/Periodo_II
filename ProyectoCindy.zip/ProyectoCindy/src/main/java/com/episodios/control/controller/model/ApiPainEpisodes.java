package com.episodios.control.controller.model;

import com.episodios.control.data.entities.PainEpisode;
import com.episodios.control.data.entities.PainEpisodeDetail;
import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

/**

 */
@Data
@ToString
public class ApiPainEpisodes extends AbstractApiObject{

    private List<ApiConsultaEpisode> lista ;

    public ApiPainEpisodes(){
        lista = new ArrayList<ApiConsultaEpisode>();
    }
}
