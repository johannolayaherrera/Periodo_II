package com.episodios.control.data.entities;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by cindymargaritapachecoalvarez on 18/06/17.
 */
@Data
@Entity
@Table(name = "detalle_episodio")
@SequenceGenerator(name = "detalle_episodio_id_detalle_episodio_seq"
        , sequenceName = "detalle_episodio_id_detalle_episodio_seq", allocationSize = 1)
public class PainEpisodeDetail implements Serializable {

  @Id
  @Column(name = "id_detalle_episodio")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "detalle_episodio_id_detalle_episodio_seq")
  private Long id;
  @ManyToOne (fetch = FetchType.LAZY)
  @JoinColumn(name = "id_episodio", nullable = false)
  private PainEpisode painEpisode;
  @ManyToOne (fetch = FetchType.LAZY)
  @JoinColumn(name = "id_nivel_dolor", nullable = false)
  private PainLevel painLevel;
  @Column(name = "medicamentos")
  private String medicines;
  @Column(name = "localizacion_dolor")
  private String painLocalization;
  @Column(name = "intensidad_dolor_localizacion")
  private String painLevelLocalization;
  @Column(name = "informacion_adicional")
  private String additionalInformation;

  public PainEpisodeDetail(){

  }

  public PainEpisodeDetail(PainEpisode painEpisode) {
    this.painEpisode = painEpisode;
  }
}
