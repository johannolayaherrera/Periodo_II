package com.episodios.control.service.impl;

import com.episodios.control.controller.PainEpisodeController;
import com.episodios.control.controller.model.ApiAutomaticAnalysis;
import com.episodios.control.controller.model.ApiPainEpisode;
import com.episodios.control.data.entities.AutomaticAnalysis;
import com.episodios.control.data.entities.Habit;
import com.episodios.control.data.entities.PainEpisode;
import com.episodios.control.data.entities.PainEpisodeArchive;
import com.episodios.control.data.entities.PainEpisodeDetail;
import com.episodios.control.data.entities.PainEpisodeDetailHabit;
import com.episodios.control.data.entities.PainLevel;
import com.episodios.control.data.entities.Patient;
import com.episodios.control.data.repository.AutomaticAnalysisRepository;
import com.episodios.control.data.repository.PainEpisodeArchiveRepository;
import com.episodios.control.data.repository.PainEpisodeDetailHabitRepository;
import com.episodios.control.data.repository.PainEpisodeDetailRepository;
import com.episodios.control.data.repository.PainEpisodeRepository;
import com.episodios.control.service.IPainEpisodeService;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import java.util.UUID;

/**
 * Created by cindymargaritapachecoalvarez on 17/06/17.
 */
@Service
public class PainEpisodeService implements IPainEpisodeService {

    private static final Logger LOG = LoggerFactory.getLogger(PainEpisodeService.class);
    @Autowired
    private PainEpisodeRepository painEpisodeRepository;
    @Autowired
    private PainEpisodeDetailRepository painEpisodeDetailRepository;
    @Autowired
    private PainEpisodeDetailHabitRepository painEpisodeDetailHabitRepository;
    @Autowired
    private AutomaticAnalysisRepository automaticAnalysisRepository;
    @Autowired
    private PainEpisodeArchiveRepository painEpisodeArchiveRepository;

    private static Properties properties = new Properties();

    private InputStream input = getClass().getClassLoader().getResourceAsStream("application.properties");

    @Transactional
    public ApiAutomaticAnalysis createPainEpisode(ApiPainEpisode apiPainEpisode) {
        long init = Calendar.getInstance().getTimeInMillis();

        ApiAutomaticAnalysis apiAutomaticAnalysis = new ApiAutomaticAnalysis();
        Patient patient = new Patient(apiPainEpisode.getPatientId());

        PainEpisode painEpisode = new PainEpisode(patient);
        painEpisode.setDate(new Date());

        painEpisode = painEpisodeRepository.save(painEpisode);

        if (apiPainEpisode.getDetails() != null) {
            PainEpisodeDetail painEpisodeDetail = new PainEpisodeDetail(painEpisode);
            painEpisodeDetail.setMedicines(apiPainEpisode.getDetails().getMedicines());
            painEpisodeDetail.setPainLocalization(apiPainEpisode.getDetails().getPainLocalization());
            painEpisodeDetail.setPainLevelLocalization(apiPainEpisode.getDetails().getPainLocalizationLevel());
            painEpisodeDetail.setAdditionalInformation(apiPainEpisode.getDetails().getAdditionalInfo());

            PainLevel painLevel = new PainLevel(apiPainEpisode.getDetails().getPainLevelId());
            painEpisodeDetail.setPainLevel(painLevel);

            painEpisodeDetail = painEpisodeDetailRepository.save(painEpisodeDetail);

            if (!apiPainEpisode.getDetails().getHabitsId().isEmpty()) {
                List<PainEpisodeDetailHabit> list = new ArrayList<>();
                for (Long habitId : apiPainEpisode.getDetails().getHabitsId()) {
                    Habit habit = new Habit(habitId);
                    PainEpisodeDetailHabit episodeHabit = new PainEpisodeDetailHabit(painEpisodeDetail, habit);
                    list.add(episodeHabit);
                }

                painEpisodeDetailHabitRepository.save(list);

            }


        }

        if (Calendar.getInstance().getTimeInMillis() - init >= 1000)
            LOG.info("Result server: {}", Calendar.getInstance().getTimeInMillis() - init);

        return null;
    }

    @Transactional
    public ApiAutomaticAnalysis createPainEpisode(ApiPainEpisode apiPainEpisode, MultipartFile file) throws Exception {

        ApiAutomaticAnalysis apiAutomaticAnalysis = new ApiAutomaticAnalysis();

        if (!file.isEmpty()) {
            try {
                byte[] bytes = file.getBytes();
                properties.load(input);

                String pathArchive = properties.getProperty("arhiveDirectory") + FilenameUtils.removeExtension(file.getOriginalFilename()) + '_' + UUID.randomUUID().toString() + '.' + FilenameUtils.getExtension(file.getOriginalFilename());

                BufferedOutputStream stream =
                        new BufferedOutputStream(new FileOutputStream(new File(pathArchive)));

                stream.write(bytes);
                stream.close();

                Patient patient = new Patient(apiPainEpisode.getPatientId());

                PainEpisode painEpisode = new PainEpisode(patient);
                painEpisode.setDate(new Date());

                PainEpisodeArchive painEpisodeArchive = new PainEpisodeArchive(pathArchive);

                painEpisode = painEpisodeRepository.save(painEpisode);
                painEpisodeArchive.setPainEpisode(painEpisode);

                List<String> results = new ArrayList<String>();
                results.add("Por el momento no hay sugerencias para la información suministrada");
                apiAutomaticAnalysis.setResults(results);

                painEpisodeArchive = painEpisodeArchiveRepository.save(painEpisodeArchive);
            } catch (Exception e) {
                throw e;
            }
        }

        return apiAutomaticAnalysis;

    }

    public List<PainEpisode> getById(Long idEpisode){
        return (List<PainEpisode>) painEpisodeRepository.findById(idEpisode);
    }

    public List<PainEpisode> getPainEpisodesByIDPatient(Long idPatient) {
        return (List<PainEpisode>) painEpisodeRepository.findPainEpisodeByIdPatient(idPatient);
    }

    public List<PainEpisode> getPainEpisodeByIdPatientAndDateBetween(Long idPatient, Date start, Date finish) {
        return (List<PainEpisode>) painEpisodeRepository.findPainEpisodeByIdPatientAndDateBetween(idPatient, start, finish);
    }
}
