package com.episodios.control.controller.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

/**
 * Created by cindymargaritapachecoalvarez on 17/06/17.
 */
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class AbstractApiObject implements Serializable {
}
