package com.episodios.control.data.entities;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by cindymargaritapachecoalvarez on 17/06/17.
 */
@Data
@Entity
@Table(name = "nivel_dolor")
@SequenceGenerator(name = "nivel_dolor_id_nivel_dolor_seq"
        , sequenceName = "nivel_dolor_id_nivel_dolor_seq", allocationSize = 1)
public class PainLevel implements Serializable{

  /** The default serial version id */
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "id_nivel_dolor")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "nivel_dolor_id_nivel_dolor_seq")
  private Long id;
  @Column(name = "descripcion")
  private String description;

  public PainLevel(){

  }

  public PainLevel(Long id){
    this.id = id;
  }
}
