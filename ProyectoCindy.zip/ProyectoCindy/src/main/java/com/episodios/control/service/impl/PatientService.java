package com.episodios.control.service.impl;
import com.episodios.control.data.entities.Patient;
import com.episodios.control.data.repository.PatientRepository;
import com.episodios.control.service.IPatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by usuario on 18/06/2017.
 */
@Service
public class PatientService implements IPatientService{
    @Autowired
    private PatientRepository  patientRepository;

    public Patient getPatientByID (Long idPatient)
    {
        return patientRepository.findOne(idPatient);

    }

    public Patient getPatientByIDUser(Long idUser)
    {
        Iterable<Patient> lPatient= patientRepository.findPatientByUserId(idUser);

        for (Patient p: lPatient)
        {
            return p;
        }

        return null;

    }
}