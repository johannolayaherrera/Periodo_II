package com.episodios.control.service.impl;

import com.episodios.control.data.entities.User;
import com.episodios.control.data.repository.UserRepository;
import com.episodios.control.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
/**
 * Created by usuario on 18/06/2017.
 */
@Service
public class UserService implements IUserService {
    @Autowired
    private UserRepository userRepository;

    public User getUserByDocumet (Long documentNumber)
    {
        Iterable<User> listUser= userRepository.findUserByDocumentNumber(documentNumber);

        for (User user: listUser)
        {

            return user;
        }
        return null;

    }
}
