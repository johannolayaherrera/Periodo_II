package com.episodios.control.data.entities;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.io.Serializable;

/**
 * Created by cindymargaritapachecoalvarez on 19/06/17.
 */
@Data
@Embeddable
public class AutomaticAnalysisKeys implements Serializable{

  @Column(name = "id_nivel_dolor")
  private Long painLevelId;
  @Column(name = "id_habito")
  private Long habitId;
}
