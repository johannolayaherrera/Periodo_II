package com.episodios.control.controller;

import com.episodios.control.TestServices.CreateEpisodeService;
import com.episodios.control.controller.model.*;
import com.episodios.control.data.entities.*;
import com.episodios.control.data.repository.AutomaticAnalysisRepository;
import com.episodios.control.data.repository.PainEpisodeRepository;
import com.episodios.control.service.IPainEpisodeDeatilService;
import com.episodios.control.service.IPainEpisodeService;
import com.episodios.control.service.IPatientService;
import com.episodios.control.service.IUserService;
import com.episodios.control.service.impl.PainEpisodeService;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.schedulers.Schedulers;

import java.util.zip.CRC32;

/**
 * Created by cindymargaritapachecoalvarez on 17/06/17.
 */
@RestController
@RequestMapping(value = "pains/episodes")
public class PainEpisodeController {

    private static final Logger LOG = LoggerFactory.getLogger(PainEpisodeController.class);
    private String privateKey = "uniandes123";

    @Autowired
    private IPainEpisodeService painEpisodeService;
    @Autowired
    private CreateEpisodeService createEpisodeService;
    @Autowired
    private AutomaticAnalysisRepository automaticAnalysisRepository;
    @Autowired
    private PainEpisodeRepository painEpisodeRepository;

    @Autowired
    private IPainEpisodeDeatilService painEpisodeDeatilService;
    @Autowired
    private IUserService userService;

    @Autowired
    private IPatientService patientService;


    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<ApiAutomaticAnalysis> createPainEpisode(@RequestHeader(value = "checkSum") String checkSum, @RequestBody ApiPainEpisode apiPainEpisodeRequest) {
        long init = Calendar.getInstance().getTimeInMillis();
        //LOG.info("Request: ({}) {}", init, apiPainEpisodeRequest);

        //Verificar integridad
        Gson gson = new Gson();
        String episodio = gson.toJson(apiPainEpisodeRequest);
        String checkSumSolicitud = obtenerCRC32(episodio,privateKey);

        ApiAutomaticAnalysis apiAutomaticAnalysis = new ApiAutomaticAnalysis();
        LOG.info("Request: ({})", checkSumSolicitud);
        LOG.info("Request: ({})", checkSum);
        //Valida si el mensaje cumple con la integridad
        if (checkSumSolicitud.equals(checkSum)) {
            createEpisodeService.createEpisode(apiPainEpisodeRequest).subscribeOn(Schedulers.io()).subscribe();
            List<String> results = automaticAnalysisRepository.findDescriptionByPainLevelAndHabitIn(
                    apiPainEpisodeRequest.getDetails().getPainLevelId(), apiPainEpisodeRequest.getDetails().getHabitsId());

            apiAutomaticAnalysis.setResults(results);
            if (Calendar.getInstance().getTimeInMillis() - init >= 1000) {
                LOG.info("Respuesta: {}", Calendar.getInstance().getTimeInMillis() - init);
            }

            //Enviando hash con la respuesta
            HttpHeaders headers = new HttpHeaders();
            String checkSumRespuesta = obtenerCRC32(apiAutomaticAnalysis.getResults().get(0),privateKey);
            headers.add("checkSum", checkSumRespuesta);

            return new ResponseEntity<>(apiAutomaticAnalysis,headers, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(apiAutomaticAnalysis, HttpStatus.BAD_REQUEST);
        }
    }

    @RequestMapping(value = "/getEpisodeId", method = RequestMethod.POST)
    public ResponseEntity<ApiPainEpisodes> requestEpisodesId(@RequestBody ApiPatientEpisodes apiPatientEpisodesRequest) {

        LOG.info("Request: {}", apiPatientEpisodesRequest);
        ApiPainEpisodes apiPainEpisodes = new ApiPainEpisodes();
        List<PainEpisode> listPainEpisode = painEpisodeService.getById(apiPatientEpisodesRequest.getDocumentNumber());

        if(listPainEpisode.size()>0) {
            List<PainEpisodeDetail> listPainEpisodeDetail = painEpisodeDeatilService.getPainEpisodeDetailOfEpisodes(listPainEpisode);
            User usuario = listPainEpisode.get(0).getPatient().getUser();
            apiPainEpisodes.setLista(cargarListaConsulta(usuario, listPainEpisodeDetail));
            return new ResponseEntity<>(apiPainEpisodes, HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(apiPainEpisodes, HttpStatus.NO_CONTENT);
        }
    }

    @RequestMapping(value = "/getEpisodePatientDocument", method = RequestMethod.POST)
    public ResponseEntity<ApiPainEpisodes> requestPatientEpisodes(@RequestBody ApiPatientEpisodes apiPatientEpisodesRequest) {

        LOG.info("Request: {}", apiPatientEpisodesRequest);

        User usuario= userService.getUserByDocumet(apiPatientEpisodesRequest.getDocumentNumber());
        Patient patient = patientService.getPatientByIDUser(usuario.getId());
        List<PainEpisode> listPainEpisode = painEpisodeService.getPainEpisodesByIDPatient(patient.getId());
        List<PainEpisodeDetail> listPainEpisodeDetail = painEpisodeDeatilService.getPainEpisodeDetailOfEpisodes(listPainEpisode);

        ApiPainEpisodes apiPainEpisodes = new ApiPainEpisodes();
        apiPainEpisodes.setLista(cargarListaConsulta(usuario,listPainEpisodeDetail));

        return new ResponseEntity<>(apiPainEpisodes,HttpStatus.OK);
    }


    @RequestMapping(value = "/getEpisodePatientBetween", method = RequestMethod.POST)
    public ResponseEntity<ApiPainEpisodes> requestPatientEpisodesBetween(@RequestBody ApiPatientEpisodesBetween apiPatientEpisodesRequest) throws ParseException {

        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date startDate = df.parse(apiPatientEpisodesRequest.getStart());
        Date finishDate = df.parse(apiPatientEpisodesRequest.getFinish());

        User usuario= userService.getUserByDocumet(apiPatientEpisodesRequest.getDocumentNumber());
        Patient patient = patientService.getPatientByIDUser(usuario.getId());
        List<PainEpisode> listaEpisodios = painEpisodeService.getPainEpisodeByIdPatientAndDateBetween(patient.getId(),startDate,finishDate);
        List<PainEpisodeDetail> listPainEpisodeDetail = painEpisodeDeatilService.getPainEpisodeDetailOfEpisodes(listaEpisodios);

        ApiPainEpisodes apiPainEpisodes = new ApiPainEpisodes();
        apiPainEpisodes.setLista(cargarListaConsulta(usuario,listPainEpisodeDetail));

        return new ResponseEntity<>(apiPainEpisodes,HttpStatus.OK);
    }

    private List<ApiConsultaEpisode> cargarListaConsulta(User usuario, List<PainEpisodeDetail> listaEpisodios){

        List<ApiConsultaEpisode> listaApiEpisodios = new ArrayList<>();
        for (PainEpisodeDetail painEpisodeDetail:listaEpisodios) {
            ApiConsultaEpisode apiPainEpisode = new ApiConsultaEpisode();
            apiPainEpisode.setTipoIdentificacion(usuario.getDocumentType().getAbbreviation());
            apiPainEpisode.setIdentificacion(usuario.getDocumentNumber());
            apiPainEpisode.setNombreApellido(usuario.getName() + " " + usuario.getLastName());
            apiPainEpisode.setFecha(String.valueOf(painEpisodeDetail.getPainEpisode().getDate()));
            apiPainEpisode.setMedicamento(painEpisodeDetail.getMedicines());
            apiPainEpisode.setLocalizacionDolor(painEpisodeDetail.getPainLocalization());
            apiPainEpisode.setIntensidadDolor(painEpisodeDetail.getPainLevel().getDescription());
            apiPainEpisode.setInformacionAdicional(painEpisodeDetail.getAdditionalInformation());
            listaApiEpisodios.add(apiPainEpisode);
        }
        return listaApiEpisodios;
    }

    //Obtiene el Hash
    private String obtenerCRC32(String mensaje, String llavePrivada){
        try {
            mensaje += llavePrivada;
            byte[] episodeAsBytes = mensaje.getBytes("UTF-8");
            CRC32 checksum = new CRC32();
            checksum.update(episodeAsBytes);
            return String.valueOf(checksum.getValue());
        } catch (UnsupportedEncodingException e) {
            return null;
        }
    }


}


