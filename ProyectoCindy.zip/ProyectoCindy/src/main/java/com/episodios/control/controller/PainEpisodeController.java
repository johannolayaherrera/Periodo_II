package com.episodios.control.controller;

import com.episodios.control.TestServices.CreateEpisodeService;
import com.episodios.control.controller.model.ApiAutomaticAnalysis;
import com.episodios.control.controller.model.ApiPainEpisode;
import com.episodios.control.data.entities.PainEpisode;
import com.episodios.control.data.entities.PainEpisodeDetail;
import com.episodios.control.data.entities.PainEpisodeDetailHabit;
import com.episodios.control.data.entities.PainLevel;
import com.episodios.control.data.entities.Patient;
import com.episodios.control.data.repository.AutomaticAnalysisRepository;
import com.episodios.control.service.IPainEpisodeService;
import com.episodios.control.service.impl.PainEpisodeService;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.schedulers.Schedulers;

import java.util.zip.CRC32;

/**
 * Created by cindymargaritapachecoalvarez on 17/06/17.
 */
@RestController
@RequestMapping(value = "pains/episodes")
public class PainEpisodeController {

    private static final Logger LOG = LoggerFactory.getLogger(PainEpisodeController.class);
    private String privateKey = "uniandes123";

    @Autowired
    private IPainEpisodeService painEpisodeService;
    @Autowired
    private CreateEpisodeService createEpisodeService;
    @Autowired
    private AutomaticAnalysisRepository automaticAnalysisRepository;


    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<ApiAutomaticAnalysis> createPainEpisode(@RequestHeader(value = "checkSum") String checkSum, @RequestBody ApiPainEpisode apiPainEpisodeRequest) {
        long init = Calendar.getInstance().getTimeInMillis();
        //LOG.info("Request: ({}) {}", init, apiPainEpisodeRequest);
        String checkSumService = "";
        Gson gson = new Gson();
        String episodio = gson.toJson(apiPainEpisodeRequest);
        checkSumService = verificarIntegridad(episodio);

        ApiAutomaticAnalysis apiAutomaticAnalysis = new ApiAutomaticAnalysis();
        //LOG.info("Request3: ({})", checkSumService);
        if (checkSumService.equals(checkSum)) {
            createEpisodeService.createEpisode(apiPainEpisodeRequest).subscribeOn(Schedulers.io()).subscribe();
            List<String> results = automaticAnalysisRepository.findDescriptionByPainLevelAndHabitIn(
                    apiPainEpisodeRequest.getDetails().getPainLevelId(), apiPainEpisodeRequest.getDetails().getHabitsId());

            apiAutomaticAnalysis.setResults(results);
            if (Calendar.getInstance().getTimeInMillis() - init >= 1000) {
                LOG.info("Respuesta: {}", Calendar.getInstance().getTimeInMillis() - init);
            }

            return new ResponseEntity<>(apiAutomaticAnalysis, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(apiAutomaticAnalysis, HttpStatus.BAD_REQUEST);
        }

    }


    @RequestMapping(value = "/getEpisodePatientBetween", method = RequestMethod.POST)
    public List<PainEpisode> getPainEpisodeBetween(Long idDocumentType, Long documentNumber, String start, String finish) throws ParseException {

        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date startDate = df.parse(start);
        Date finishDate = df.parse(finish);
        return painEpisodeService.getPainEpisodeBetween(idDocumentType, documentNumber, startDate, finishDate);
    }

    private String verificarIntegridad(String episode) {
        byte[] episodeAsBytes = new byte[0];
        episode = privateKey + episode;
        try {
            episodeAsBytes = episode.getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        CRC32 checksum = new CRC32();
        checksum.update(episodeAsBytes);
        return String.valueOf(checksum.getValue());
    }


}


