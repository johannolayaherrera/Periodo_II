package com.episodios.control.data.entities;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by cindymargaritapachecoalvarez on 16/06/17.
 */
@Data
@Entity
@Table(name = "paciente")
@SequenceGenerator(name = "paciente_id_paciente_seq"
        , sequenceName = "paciente_id_paciente_seq", allocationSize = 1)
public class Patient implements Serializable{

  /**
   * The default serial version id
   */
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "id_paciente")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "paciente_id_paciente_seq")
  private Long id;
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "id_usuario", nullable = false)
  private User user;
  @Column(name = "eps")
  private String eps;

  public Patient(){

  }

  public Patient(Long id) {
    this.id = id;
  }

}
