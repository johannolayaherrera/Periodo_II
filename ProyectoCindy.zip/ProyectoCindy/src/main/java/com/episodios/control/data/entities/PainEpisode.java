package com.episodios.control.data.entities;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by cindymargaritapachecoalvarez on 16/06/17.
 */
@Data
@Entity
@Table(name = "episodio")
@SequenceGenerator(name = "episodio_id_episodio_seq"
        , sequenceName = "episodio_id_episodio_seq", allocationSize = 1)
public class PainEpisode implements Serializable {

  /**
   * The default serial version id
   */
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "id_episodio")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "episodio_id_episodio_seq")
  private Long id;
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "id_paciente", nullable = false)
  private Patient patient;
  @Column(name = "fecha")
  private Date date;

  @OneToOne
  @JoinColumn(name = "id_episodio", nullable = false)
  private PainEpisodeArchive painEpisodeArchive;

  public PainEpisode(){

  }

  public PainEpisode(Patient patient) {
    this.patient = patient;
  }

}
