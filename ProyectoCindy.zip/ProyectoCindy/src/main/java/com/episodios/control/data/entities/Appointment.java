package com.episodios.control.data.entities;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by cindymargaritapachecoalvarez on 16/06/17.
 */
@Data
@Entity
@Table(name = "cita")
@SequenceGenerator(name = "cita_id_cita_seq"
        , sequenceName = "cita_id_cita_seq", allocationSize = 1)
public class Appointment implements Serializable {

  /** The default serial version id */
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "id_cita")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cita_id_cita_seq")
  private Long id;
  @ManyToOne
  @JoinColumn(name = "id_doctor", nullable = false)
  private Doctor doctor;
  @ManyToOne
  @JoinColumn(name = "id_paciente", nullable = false)
  private Patient patient;
  @Column(name = "fecha")
  private Date date;
  @Column(name = "consultorio")
  private String office;

}
