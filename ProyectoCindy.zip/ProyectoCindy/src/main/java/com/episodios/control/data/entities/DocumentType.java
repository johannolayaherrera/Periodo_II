package com.episodios.control.data.entities;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by cindymargaritapachecoalvarez on 17/06/17.
 */
@Data
@Entity
@Table(name = "tipo_documento")
@SequenceGenerator(name = "tipo_documento_id_tipo_documento_seq"
        , sequenceName = "tipo_documento_id_tipo_documento_seq", allocationSize = 1)
public class DocumentType implements Serializable {

  /**
   * The default serial version id
   */
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "id_tipo_documento")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "tipo_documento_id_tipo_documento_seq")
  private Long id;
  @Column(name = "nombre")
  private String name;
  @Column(name = "abreviatura")
  private String abbreviation;
}
