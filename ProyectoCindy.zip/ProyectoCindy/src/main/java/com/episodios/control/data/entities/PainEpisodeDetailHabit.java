package com.episodios.control.data.entities;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by cindymargaritapachecoalvarez on 16/06/17.
 */
@Data
@Entity
@Table(name = "habito_detalle_episodio")
public class PainEpisodeDetailHabit implements Serializable {

  /**
   * The default serial version id
   */
  private static final long serialVersionUID = 1L;

  @EmbeddedId
  private PainEpisodeDetailHabitKeys id;
  @ManyToOne
  @JoinColumn(name = "id_detalle_episodio", nullable = false, insertable = false, updatable = false)
  private PainEpisodeDetail painEpisodeDetail;
  @ManyToOne
  @JoinColumn(name = "id_habito", nullable = false, insertable = false, updatable = false)
  private Habit habit;

  public PainEpisodeDetailHabit(){

  }

  public PainEpisodeDetailHabit(PainEpisodeDetail painEpisodeDetail, Habit habit) {

    this.id = new PainEpisodeDetailHabitKeys(painEpisodeDetail.getId(), habit.getId());
    this.painEpisodeDetail = painEpisodeDetail;
    this.habit = habit;
  }
}
