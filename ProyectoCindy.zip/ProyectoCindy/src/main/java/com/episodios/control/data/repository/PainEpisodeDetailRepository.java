package com.episodios.control.data.repository;

import com.episodios.control.data.entities.PainEpisode;
import com.episodios.control.data.entities.PainEpisodeDetail;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

/**
 * Created by usuario on 18/06/2017.
 */
public interface PainEpisodeDetailRepository extends CrudRepository<PainEpisodeDetail, Integer>{

    @Query("Select ped from PainEpisodeDetail ped join ped.painEpisode p where p.id =:idPainEpisode")
    Iterable<PainEpisodeDetail> findPainEpisodeDetailByIDPainEpisode(@Param("idPainEpisode") Long idPainEpisode);
}
