package com.episodios.control.data.entities;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;


/**
 * Created by edgaguil on 18/06/2017.
 */
@Data
@Entity
@Table(name = "archivo_episodio")
@SequenceGenerator(name = "archivo_episodio_id_archivo_episodio_seq"
        , sequenceName = "archivo_episodio_id_archivo_episodio_seq", allocationSize = 1)
public class PainEpisodeArchive implements Serializable {
    /** The default serial version id */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id_archivo_episodio")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "archivo_episodio_id_archivo_episodio_seq")
    private Long id;
    @Column(name = "ruta")
    private String ruta;

    @ManyToOne
    @JoinColumn(name = "id_episodio", nullable = false)
    private PainEpisode painEpisode;

    public PainEpisodeArchive(){}

    public PainEpisodeArchive(String ruta){
        this.ruta = ruta;
    }
}
