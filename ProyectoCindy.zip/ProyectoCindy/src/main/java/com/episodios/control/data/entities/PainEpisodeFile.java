package com.episodios.control.data.entities;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by cindymargaritapachecoalvarez on 18/06/17.
 */
@Data
@Entity
@Table(name = "archivo_episodio")
@SequenceGenerator(name = "archivo_episodio_id_archivo_episodio_seq"
        , sequenceName = "archivo_episodio_id_archivo_episodio_seq", allocationSize = 1)
public class PainEpisodeFile implements Serializable {

  /**
   * The default serial version id
   */
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "id_archivo_episodio")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "archivo_episodio_id_archivo_episodio_seq")
  private Long id;
  @ManyToOne
  @JoinColumn(name = "id_episodio", nullable = false)
  private PainEpisode painEpisode;
  @Column(name = "ruta")
  private String path;
}
