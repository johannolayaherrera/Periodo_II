package com.episodios.control.data.repository;

import com.episodios.control.data.entities.PainEpisodeDetail;
import com.episodios.control.data.entities.PainEpisodeDetailHabit;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by cindymargaritapachecoalvarez on 19/06/17.
 */
public interface PainEpisodeDetailHabitRepository extends CrudRepository<PainEpisodeDetailHabit, Integer> {
}
