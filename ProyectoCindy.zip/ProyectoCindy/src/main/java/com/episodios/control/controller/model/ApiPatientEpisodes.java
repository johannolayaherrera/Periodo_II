package com.episodios.control.controller.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.List;

/**
 * Created by usuario on 18/06/2017.
 */
@Data
@ToString
@EqualsAndHashCode
public class ApiPatientEpisodes extends AbstractApiObject
{
    private Long documentNumber;
}