package com.episodios.control;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControlEpisodiosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControlEpisodiosApplication.class, args);
	}
}
