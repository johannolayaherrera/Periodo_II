package com.episodios.control.service;

import com.episodios.control.data.entities.PainEpisode;
import com.episodios.control.data.entities.PainEpisodeDetail;
import java.util.List;
/**
 * Created by usuario on 19/06/2017.
 */
public interface IPainEpisodeDeatilService {

  List<PainEpisodeDetail> getPainEpisodeDetailOfEpisodes(List<PainEpisode> listPainEpisode) ;
}
