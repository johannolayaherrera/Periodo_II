package com.episodios.control.TestServices;

import com.episodios.control.controller.model.ApiPainEpisode;
import com.episodios.control.service.IPainEpisodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import rx.Observable;

/**
 * Created by cindymargaritapachecoalvarez on 1/07/17.
 */
@Service
public class CreateEpisodeService {

  @Autowired
  private IPainEpisodeService painEpisodeService;


  public Observable<Void> createEpisode(ApiPainEpisode apiPainEpisode){
    return Observable.create(s->{
      painEpisodeService.createPainEpisode(apiPainEpisode);
      s.onCompleted();

            }
    );

  }
}
