package com.episodios.control.service;

import com.episodios.control.controller.model.ApiAutomaticAnalysis;
import com.episodios.control.controller.model.ApiPainEpisode;
import com.episodios.control.data.entities.PainEpisode;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;
import java.util.List;

/**
 * Created by cindymargaritapachecoalvarez on 17/06/17.
 */
public interface IPainEpisodeService {

  ApiAutomaticAnalysis createPainEpisode(ApiPainEpisode apiPainEpisode);

  List<PainEpisode> getPainEpisodesByIDPatient(Long idPatient);

  List<PainEpisode> getPainEpisodeBetween(Long idDocumentType, Long documentNumber, Date start, Date finish);

  ApiAutomaticAnalysis createPainEpisode(ApiPainEpisode apiPainEpisode, MultipartFile file) throws Exception;

}
