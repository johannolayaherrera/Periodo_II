package com.episodios.control.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.episodios.control.controller.model.ApiAutomaticAnalysis;
import com.episodios.control.controller.model.ApiPatientEpisodes;
import com.episodios.control.data.entities.PainEpisode;
import com.episodios.control.data.entities.PainEpisodeDetail;
import com.episodios.control.data.entities.Patient;
import com.episodios.control.data.entities.User;
import com.episodios.control.service.IPainEpisodeDeatilService;
import com.episodios.control.service.IPainEpisodeService;
import com.episodios.control.service.IPatientService;
import com.episodios.control.service.IUserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by usuario on 19/06/2017.
 */
@RestController
@RequestMapping(value = "patient/episodes")
public class PatientPainEpisodesController {

    private static final Logger LOG = LoggerFactory.getLogger(PatientPainEpisodesController.class);
    @Autowired
    private IPainEpisodeService painEpisodeService;

    @Autowired
    private IUserService userService;

    @Autowired
    private IPatientService patientService;

    @Autowired
    private IPainEpisodeDeatilService painEpisodeDeatilService;

    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<ApiAutomaticAnalysis> requestPatientEpisodes(@RequestBody ApiPatientEpisodes apiPatientEpisodesRequest) {

        LOG.info("Request: {}", apiPatientEpisodesRequest);

        User user= userService.getUserByDocumet(apiPatientEpisodesRequest.getDocumentNumber());
        Patient patient = patientService.getPatientByIDUser(user.getId());
        List<PainEpisode> listPainEpisode = painEpisodeService.getPainEpisodesByIDPatient(patient.getId());
        List<PainEpisodeDetail> listPainEpisodeDetail = painEpisodeDeatilService.getPainEpisodeDetailOfEpisodes(listPainEpisode);

        ApiAutomaticAnalysis apiAutomaticAnalysis = new ApiAutomaticAnalysis();
        List<String> results = new ArrayList<String>();
        results.add("Usuario: " + user.getName());
        for (PainEpisodeDetail pEpisodeDetail:listPainEpisodeDetail) {
            List<String> p= Arrays.asList("Episodio: " + pEpisodeDetail.getId(), "Localizacion: " +pEpisodeDetail.getPainLocalization(), "Nivel Dolor: " + pEpisodeDetail.getPainLevel().getDescription()  );
            results.addAll(p);
        }
        apiAutomaticAnalysis.setResults(results);
        return new ResponseEntity<ApiAutomaticAnalysis>(apiAutomaticAnalysis, HttpStatus.OK);
    }
}
