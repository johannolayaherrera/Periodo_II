package com.episodios.control.controller.model;

import lombok.Data;


/**
 * Created by edgaguil on 18/06/2017.
 */
@Data
public class ApiEpisodeArchive extends AbstractApiObject {
    private Integer episodeArchiveId;
    private String archivePath;
    private Integer episodeId;
}
