package com.episodios.control.data.entities;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by cindymargaritapachecoalvarez on 16/06/17.
 */
@Data
@Entity
@Table(name = "usuario")
@SequenceGenerator(name = "usuario_id_usuario_seq"
        , sequenceName = "usuario_id_usuario_seq", allocationSize = 1)
public class User implements Serializable {

  /**
   * The default serial version id
   */
  private static final long serialVersionUID = 1L;


  @Id
  @Column(name = "id_usuario")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "usuario_id_usuario_seq")
  private Long id;
  @Column(name = "login")
  private String login;
  @Column(name = "password")
  private String password;
  @Column(name = "nombre")
  private String name;
  @Column(name = "apellido")
  private String lastName;
  @Column(name = "genero")
  private String gender;
  @Column(name = "fecha_nacimiento")
  private Date birthdate;
  @Column(name = "numero_documento")
  private Long documentNumber;
  @ManyToOne (fetch = FetchType.LAZY)
  @JoinColumn(name = "id_tipo_documento", nullable = false)
  private DocumentType documentType;

  public User(){

  }

  public User(Long id){
    this.id = id;
  }
}
