package com.episodios.control.service;
import com.episodios.control.data.entities.Patient;
/**
 * Created by usuario on 18/06/2017.
 */
public interface IPatientService
{
    public Patient getPatientByID (Long idPatient);
    public Patient getPatientByIDUser(Long idUser);
}
