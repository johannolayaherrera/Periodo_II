package com.episodios.control.service;
import com.episodios.control.data.entities.User;
/**
 * Created by usuario on 18/06/2017.
 */
public interface IUserService
{
    public User getUserByDocumet (Long documentNumber);


}