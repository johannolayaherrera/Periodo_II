package com.episodios.control.data.repository;
import com.episodios.control.data.entities.PainEpisode;
import com.episodios.control.data.entities.Patient;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

/**
 * Created by usuario on 18/06/2017.
 */
public interface PatientRepository extends CrudRepository<Patient, Long> {

    @Query("Select p from Patient p join p.user u where u.id =:idUser")
    public Iterable<Patient> findPatientByUserId(@Param("idUser") Long idUser);
}

