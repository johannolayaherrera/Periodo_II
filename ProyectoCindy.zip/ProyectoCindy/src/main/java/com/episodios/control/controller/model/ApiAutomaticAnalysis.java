package com.episodios.control.controller.model;

import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by cindymargaritapachecoalvarez on 17/06/17.
 */
@Data
@ToString
public class ApiAutomaticAnalysis extends AbstractApiObject{

  private List<String> results;

  public ApiAutomaticAnalysis(){
    results = new ArrayList<String>();
  }
}
