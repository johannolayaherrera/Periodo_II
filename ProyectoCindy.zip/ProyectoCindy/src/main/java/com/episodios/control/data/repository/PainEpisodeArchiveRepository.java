package com.episodios.control.data.repository;

import com.episodios.control.data.entities.*;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


/**
 * Created by edgaguil on 19/06/2017.
 */
public interface PainEpisodeArchiveRepository extends CrudRepository<PainEpisodeArchive, Integer> {
}
