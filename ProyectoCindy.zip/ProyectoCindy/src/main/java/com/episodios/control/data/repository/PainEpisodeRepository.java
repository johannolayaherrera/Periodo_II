package com.episodios.control.data.repository;

import com.episodios.control.data.entities.PainEpisode;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;

/**
 * Created by cindymargaritapachecoalvarez on 16/06/17.
 */
public interface PainEpisodeRepository extends CrudRepository<PainEpisode, Integer> {

    @Query("Select pe from PainEpisode pe join pe.patient p where p.id =:idPatient")
    Iterable<PainEpisode> findPainEpisodeByIdPatient(@Param("idPatient") Long idPatient);

  List<PainEpisode> findByPatient_User_DocumentType_IdAndPatient_User_DocumentNumberAndDateBetween(Long idDocumentType, Long documentNumber, Date start, Date finish);
}
