package com.episodios.control.data.repository;

import com.episodios.control.data.entities.PainEpisode;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;

/**
 * Created by cindymargaritapachecoalvarez on 16/06/17.
 */
public interface PainEpisodeRepository extends CrudRepository<PainEpisode, Integer> {

    @Query("Select pe from PainEpisode pe  where pe.id =:idEpisode")
    Iterable<PainEpisode> findById(@Param("idEpisode") Long idEpisode);

    @Query("Select pe from PainEpisode pe join pe.patient p where p.id =:idPatient")
    Iterable<PainEpisode> findPainEpisodeByIdPatient(@Param("idPatient") Long idPatient);

    @Query("Select pe from PainEpisode pe join pe.patient p  where p.id =:idPatient and pe.date between :start and :finish")
    Iterable<PainEpisode> findPainEpisodeByIdPatientAndDateBetween(@Param("idPatient") Long idPatient, @Param("start") Date start,@Param("finish") Date finish);



}
