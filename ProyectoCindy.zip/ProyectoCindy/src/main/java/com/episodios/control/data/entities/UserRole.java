package com.episodios.control.data.entities;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by cindymargaritapachecoalvarez on 17/06/17.
 */
@Data
@Entity
@Table(name = "rol_usuario")
public class UserRole implements Serializable {

  /**
   * The default serial version id
   */
  private static final long serialVersionUID = 1L;

  @Id
  private Long id;
  @ManyToOne
  @JoinColumn(name = "id_usuario", nullable = false)
  private User user;
  @ManyToOne
  @JoinColumn(name = "id_role", nullable = false)
  private Role role;
}
