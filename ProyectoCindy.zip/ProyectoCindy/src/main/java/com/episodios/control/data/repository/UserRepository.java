package com.episodios.control.data.repository;
import com.episodios.control.data.entities.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

/**
 * Created by usuario on 18/06/2017.
 */

public interface UserRepository extends CrudRepository<User, Long> {

    @Query("Select u from User u where u.documentNumber=:documentNumber")
    public Iterable<User> findUserByDocumentNumber(@Param("documentNumber") Long documentNumber);
}
