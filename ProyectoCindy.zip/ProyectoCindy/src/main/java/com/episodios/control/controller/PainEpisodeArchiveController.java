package com.episodios.control.controller;

import com.episodios.control.controller.model.ApiAutomaticAnalysis;
import com.episodios.control.controller.model.ApiPainEpisode;
import com.episodios.control.data.entities.PainEpisode;
import com.episodios.control.data.entities.PainLevel;
import com.episodios.control.service.IPainEpisodeService;
import com.episodios.control.service.impl.PainEpisodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;


/**
 * Created by edgaguil on 18/06/2017.
 */

@RestController
@RequestMapping(value = "pains/episodes/archive")
public class PainEpisodeArchiveController {

    @Autowired
    private IPainEpisodeService painEpisodeService;

    @RequestMapping(method = RequestMethod.POST, headers = "Content-Type= multipart/form-data")
    public ResponseEntity<ApiAutomaticAnalysis> createPainEpisode(@RequestParam("patientId") Long patientId, @RequestParam(value = "file", required = false) MultipartFile file ) throws Exception {
        ApiPainEpisode episode = new ApiPainEpisode();
        episode.setPatientId(patientId);
        ApiAutomaticAnalysis apiAutomaticAnalysis = painEpisodeService.createPainEpisode(episode, file);
        return new ResponseEntity<ApiAutomaticAnalysis>(apiAutomaticAnalysis, HttpStatus.OK);
    }
}
