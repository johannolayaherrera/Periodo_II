﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Mockups
{
    public partial class frmCrearOferta : System.Web.UI.Page
    {
        private Table formulario = new Table();
        private BDPruebaEntities DataContext = new BDPruebaEntities();
        private int ID_TIPO_CONTROL_NINGUNO = 1;
        private int ID_TIPO_CONTROL_TEXTO = 2;
        private int ID_TIPO_CONTROL_LISTA = 3;
        private string CEDULA = "123";

        private string nombreItem = "_item";
        private string controlItem = "_control";
        private string botonEliminar = "_btnEliminar";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (GetPostBackControl(this) == null)
            {
                crearFormularioDinamico(CEDULA);
            }
        }

        protected void btnAgregarItem_Click(object sender, EventArgs e)
        {
            pnlNuevoItem.Visible = true;

            btnAgregarItem.Visible = false;

            cargarTipoControl();
            PanelFormularioDinamico.Visible = true;
            crearFormularioDinamico(CEDULA);
        }

        private void cargarTipoControl()
        {
            ddlTipoControl.DataSource = DataContext.spObtenerTipoControl().ToList();
            ddlTipoControl.DataValueField = "IdTipoControl";
            ddlTipoControl.DataTextField = "TipoControl";
            ddlTipoControl.DataBind();
        }

        protected void btnGuardarItem_Click(object sender, EventArgs e)
        {

            string respuestas = tbxSeparador.Text.Trim() == "" ? "" : tbxRespuesta.Text.Replace(tbxSeparador.Text.Trim(), "|");
            DataContext.spInsertarItemFormularioTemporal(CEDULA, tbxItem.Text, Convert.ToInt16(ddlTipoControl.SelectedItem.Value), respuestas);

            pnlNuevoItem.Visible = false;

            btnAgregarItem.Visible = true;
            crearFormularioDinamico(CEDULA);
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            pnlNuevoItem.Visible = false;
            btnAgregarItem.Visible = true;
        }

        private void crearFormularioDinamico(string Cedula)
        {
            List<spObtenerFormularioTemporal_Result> items = DataContext.spObtenerFormularioTemporal(Cedula).ToList();

            foreach (var item in items)
            {
                //Se guarda el identificador del item es el idItem_TipodeControl
                string identificadorItem = item.IdItem.ToString() + "_" + item.IdTipoControl.ToString();

                TableRow trItem = new TableRow();
                trItem.ID = identificadorItem;
                TableCell tdNombreItem = new TableCell();

                Label lblItem = new Label();
                lblItem.ID = identificadorItem + nombreItem;
                lblItem.Text = item.Item + " ";
                tdNombreItem.Controls.Add(lblItem);
                trItem.Cells.Add(tdNombreItem);

                TableCell tdControl = new TableCell();

                switch (item.IdTipoControl)
                {
                    case 1:
                        Label lblTitulo = new Label();
                        lblTitulo.Font.Size = 50;
                        lblTitulo.ID = identificadorItem + controlItem;
                        tdControl.Controls.Add(lblTitulo);
                        trItem.Cells.Add(tdControl);
                        break;
                    case 2:
                        Label lblDescripcion = new Label();
                        lblDescripcion.Font.Size = 10;
                        lblDescripcion.ID = identificadorItem + controlItem;
                        tdControl.Controls.Add(lblDescripcion);
                        trItem.Cells.Add(tdControl);
                        break;
                    case 3:
                        Label lblComentario = new Label();
                        lblComentario.Font.Size = 6;
                        lblComentario.ID = identificadorItem + controlItem;
                        tdControl.Controls.Add(lblComentario);
                        trItem.Cells.Add(tdControl);
                        break;
                    case 4:
                        TextBox tbxItem = new TextBox();
                        tbxItem.ID = identificadorItem + controlItem;
                        tdControl.Controls.Add(tbxItem);
                        trItem.Cells.Add(tdControl);
                        break;
                    case 5:
                        DropDownList ddlItem = new DropDownList();
                        ddlItem.ID = identificadorItem + controlItem;
                        tdControl.Controls.Add(ddlItem);
                        trItem.Cells.Add(tdControl);
                        cargarRespuestasItem(ddlItem, item.IdItem);
                        break;
                    case 6:
                        FileUpload fupItem = new FileUpload();
                        fupItem.ID = identificadorItem + controlItem;
                        tdControl.Controls.Add(fupItem);
                        trItem.Cells.Add(tdControl);
                        break;
                }

                TableCell tdbtnEliminar = new TableCell();

                Button btnEliminar = new Button();
                btnEliminar.ID = item.IdItem + botonEliminar;
                btnEliminar.Click += new EventHandler(btnEliminarItem_Click);
                btnEliminar.Text = "Eliminar";

                tdbtnEliminar.Controls.Add(btnEliminar);
                trItem.Cells.Add(tdbtnEliminar);
                //Se guarda el item en la tabla 
                formulario.Rows.Add(trItem);
            }
            PanelFormularioDinamico.Controls.Add(formulario);
        }

        private void cargarRespuestasItem(DropDownList ddlCalificacion, int? idItem)
        {
            ddlCalificacion.DataSource = DataContext.spObtenerRespuestaItem(idItem);
            ddlCalificacion.DataTextField = "Respuesta";
            ddlCalificacion.DataValueField = "IdRespuesta";
            ddlCalificacion.DataBind();
        }

        protected void btnEliminarItem_Click(object sender, EventArgs e)
        {
            Button btnEvento = (Button)sender;
            int idItem = Convert.ToInt16(btnEvento.ID.Split('_')[0]);
            DataContext.spEliminarItemFormularioTemporal(idItem);
            PanelFormularioDinamico.Visible = false;
        }

        protected void btnActualizarFormulario_Click(object sender, EventArgs e)
        {
            crearFormularioDinamico(CEDULA);
            PanelFormularioDinamico.Visible = true;
        }

        private void visualizacionControlItems(string selectedValue)
        {
            switch (selectedValue)
            {
                case "5":
                    trSeparador.Visible = true;
                    trOpciones.Visible = true;
                    break;
                default:
                    trSeparador.Visible = false;
                    trOpciones.Visible = false;
                    break;
            }
        }

        public Control GetPostBackControl(Page page)
        {
            Control control = null;

            string ctrlname = page.Request.Params.Get("__EVENTTARGET");
            if (ctrlname != null && ctrlname != string.Empty)
            {
                control = page.FindControl(ctrlname);
            }
            else
            {
                foreach (string ctl in page.Request.Form)
                {
                    Control c = page.FindControl(ctl);
                    if (c is System.Web.UI.WebControls.Button)
                    {
                        control = c;
                        break;
                    }
                }
            }
            return control;
        }

        protected void ddlTipoControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            visualizacionControlItems(ddlTipoControl.SelectedItem.Value);
            crearFormularioDinamico(CEDULA);
        }

        protected void btnGuardarOferta_Click(object sender, EventArgs e)
        {
            //Se guarda primero la oferta, esta parte queda pendiente

            //Se guarda el formulario 
            DataContext.spCrearFormularioProceso(CEDULA);
            mostrarMensaje("El formulario se ha agregado correctamente.");
            //Se asocia el formulario al proceso
        }

        private void mostrarMensaje(string mensaje)
        {
            //lblError.Text = mensaje;
            //lblError.Visible = true;
            ScriptManager.RegisterStartupScript(this.Page, GetType(), "Mensaje", "<script>alert('" + mensaje + "');</script>", false);
        }
    }
}